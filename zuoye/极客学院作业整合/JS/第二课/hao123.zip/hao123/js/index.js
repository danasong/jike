function change (e) {
	switch(e){
		case 'yellow'
			
	}
}