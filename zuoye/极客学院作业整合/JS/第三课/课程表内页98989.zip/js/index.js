/*头部jquery*/
$(".head-div").children("ul").children("li").hover(
	function() {
		$(this).css("color","#2DB855");
		$(this).children("a").css("color","#2DB855");
		$(this).children(".arrow-icon").attr("class","arrow-icon rotate animation done ");
		$(this).children(".submenu").fadeIn("slow");
	},
	function () {
		$(this).css("color","#000");
		$(this).children("a").css("color","#000");
		$(this).children(".submenu").css("display","none");
		$(this).children(".arrow-icon").attr("class","arrow-icon");
  }
);
$("#search-btn").hover(
	function(){
		$(this).attr("class","search-icon seek-hover");
	},
	function(){
		$(this).attr("class","search-icon");
	}
);
$(".app-icon").hover(
	function(){
		$(this).attr("class","app-icon relative app-hover");
		$("#app-div-submenu").fadeIn("slow");
	},function(){
		$(this).attr("class","app-icon relative");
		$("#app-div-submenu").hide();
});
$(".logged").hover(
	function () {
		$(".submenus").fadeIn("slow");
	},function(){
		$(".submenus").hide();
	}
);
$(".submenus").children("dd").hover(
	function(){
		$(this).css("background","#F5F5F5");
	},function(){
		$(this).css("background","#fff");
	}
);
/*课程库jquery*/
$(".aside-cList").children("li").hover(
	function(){
		$(this).children("[name=course-div]").attr("class","course-div right-course");
		$(this).children("[name=course-div]").children("a").attr("class","right-a");
		$(this).children("[name=course-div]").children(".list-show").show();
	},function(){
		$(this).children("[name=course-div]").attr("class","course-div");
		$(this).children("[name=course-div]").children("a").attr("class","");
		$(".list-show").hide();
	}
);
$(".hdlist").children("li").hover(
	function(){
		$(this).children("a").attr("class","all-li-a");
	},function(){
		$(this).children("a").attr("class","");
	}
);
$(".lesson-list-div").children("ul").children("li").hover(
	function(){
		$(this).children(".lesson-box").children(".user-action").css("opacity","1");
		$(this).children(".lesson-box").children("a").children(".lessonplay").css("opacity","1");
		$(this).children(".lesson-infor").animate({height:'+175px'},"slow");
	},function(){
		$(this).children(".lesson-box").children(".user-action").css("opacity","0");
		$(this).children(".lesson-box").children("a").children(".lessonplay").css("opacity","0");
		$(this).children(".lesson-infor").animate({height:'+88px'},"slow");
	}
);
$(".sortMode").children("dl").hover(
	function(){
		$(this).children("dd").css("opacity","1");
		$(this).css("border","1px solid #EFECEC");
		$(this).children("dd").css("display","block");
	},function(){
		$(this).children("dd").css("opacity","0");
		$(this).css("border","")
		$(this).children("dd").css("display","none");
	}
);
$(".sortMode").children("dl").children("dd").children("p").hover(
	function(){
		$(this).children("a").css("color","#35B558");
	},function(){
		$(this).children("a").css("color","");
	}
);
$(".list-icon ").click(
	function(){
		$(".lesson-list-div").children("ul").children("li").attr("class","samyak-charitra");
		$(".lesson-list-div").children("ul").children(".lesson-box").attr("class","lesson-box-sam");
		$(".lesson-list-div").children("ul").children(".lesson-infor").attr("class","lesson-infor-sam");
		$(".lesson-list-div").children("ul").children(".lesson-infor").children("h2").attr("class","lesson-infor-h2-sam");
		$(".lesson-list-div").children("ul").children(".lesson-infor").children("p").attr("class","lesson-infor-p-sam");
		$(".lesson-list-div").children("ul").children(".lesson-infor").children(".timeandicon").attr("class","timeandicon-sam");
		$(".lesson-list-div").children("ul").children(".lesson-infor").children(".timeandicon").children(".lessonicon-box").attr("class","lessonicon-box-sam");
	}
);