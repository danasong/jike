/*右侧滑动栏*/
$("#product").hover(
	function() {
		$("#hide").show();

	},
	function () {
   	    $("#hide").hide();
  }
);
$("#hide").hover(
	function() {
		$("#hide").show();

	},
	function () {
   	    $("#hide").hide();
  }
);
/*中间切屏*/
$(".s-menu-item").click(
	function(){
	  var a=$(this).attr("data-id");
	  if (a==1) {
	  	$(".s-menu-item").attr("class","s-menu-item");
	  	$(this).attr("class","s-menu-item current");
	  	var name=$(this).attr("name");
	  	switch(name){
	  		case "ecommend-span":
	  			$(".s_ctner_contents").hide();
	  			$(".mine-icon").attr("class","mine-icon");
	  			$("#s_menu_mine").attr("class","not");
	  		 	$("[name=ecommend-span]").show();
	  		 	return;
	  		case "navigation-span":
	  			$(".s_ctner_contents").hide();
	  			$(".mine-icon").attr("class","mine-icon");
	  			$("[name=navigation-span]").show();
	  			return;
	  		case "video-span":
	  			$(".s_ctner_contents").hide();
	  			$(".mine-icon").attr("class","mine-icon");
	  			$("[name=video-span]").show();
	  			return;
	  		case "shopping-span":
	  			$(".s_ctner_contents").hide();
	  			$(".mine-icon").attr("class","mine-icon");
	  			$("[name=shopping-span]").show();
	  			return;
	  	}
	  }else{
	  	$(".s-menu-item").attr("class","s-menu-item");
	  	$(this).attr("class","s-menu-item current"); 
	  	$(".s-menu-item").attr("data-id","2");
	  	$(this).attr("data-id","1");
	  	var name=$(this).attr("name");
	  	switch(name){
	  		case "ecommend-span":
	  			$(".s_ctner_contents").hide();
	  			$(".mine-icon").attr("class","mine-icon");
	  			$("#s_menu_mine").attr("class","not");
	  		 	$("[name=ecommend-span]").show();
	  		 	return;
	  		case "navigation-span":
	  			$(".s_ctner_contents").hide();
	  			$(".mine-icon").attr("class","mine-icon");
	  			$("#s_menu_mine").attr("class","not");
	  			$("[name=navigation-span]").show();
	  			return;
	  		case "video-span":
	  			$(".s_ctner_contents").hide();
	  			$(".mine-icon").attr("class","mine-icon");
	  			$("#s_menu_mine").attr("class","not");
	  			$("[name=video-span]").show();
	  			return;
	  		case "shopping-span":
	  			$(".s_ctner_contents").hide();
	  			$(".mine-icon").attr("class","mine-icon");
	  			$("#s_menu_mine").attr("class","not");
	  			$("[name=shopping-span]").show();
	  			return;
	  	}
	  }
	}
);
$("#s_menu_mine").click(
	function(){
		$(".s-menu-item").attr("class","s-menu-item");
		$(this).attr("class","current");
		$(".mine-icon").attr("class","mine-icons mine-icon");
		$(".s_ctner_contents").hide();
		$("[name=ro-navigation]").show();
	}
);
/*换肤*/
$("#in-clothing-a").click(
		function(){
			$(".s-skin-layer").fadeToggle("fast");
			$(".s-skin-layer").show();
		}

);
$("#pacl-span").click(
	function(){
		$(".s-skin-layer").fadeToggle("fast");
		$(".s-skin-layer").hide();
	}
);