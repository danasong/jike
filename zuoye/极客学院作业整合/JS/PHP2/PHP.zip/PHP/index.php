<?php
	header('Content-Type: text/html; charset=utf-8'); 
	//$con = mysql_connect("121.40.78.18","root","austar999");
	/*$con = mysql_connect("127.0.0.1","root","");
	if ($con)
  	{
  	}
	mysql_close($con);*/
	Console.log(1);
?>